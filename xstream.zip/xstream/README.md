# XStream

A mobile-first streaming platform demo — Movies, Music, Live TV, News, Search, Favorites, and Profile — built with React + TypeScript + Vite. All content is placeholder/demo data; no real movie, TV, or music assets are used.

## What's built so far

- Full project scaffold (routing, layout, design system)
- **Home**: TikTok-style full-screen vertical video feed — snap-scroll, auto-play/pause of only the active video, mute toggle, like/comment/share/favorite/follow, progress bar. Video playback is *simulated* with animated gradient placeholders — see "About video playback" below.
- **Discover**: trending videos grid, movies/music/live/news rows (from the original catalog), creators to follow
- **Create**: demo video-upload form (title, description, hashtags, thumbnail picker, publish) — no backend
- **Following**: vertical feed filtered to creators the demo user already follows
- **Profile**: avatar, bio, stats, Videos/Favorites tabs
- Bottom tab navigation (Home / Discover / Create / Following / Profile) — Create is visually distinct
- Legacy Movies/Music/LiveTV/News/Search/Favorites pages are kept and still routable, just not in the main tab bar anymore

## About video playback

No real video files are bundled (per the "no copyrighted clips" requirement). Each "video" is an animated gradient placeholder with a `DEMO CLIP` watermark, a simulated progress bar, and play/pause driven by real state — the interaction model is fully functional, so swapping in real `<video src>` elements later is a drop-in change inside `VideoCard.tsx`.

## Design system

- Dark charcoal-teal background (`#0f1417`) rather than pure black, with a warm amber accent (`#e8a33d`) — kept out of the usual "black + neon green" streaming-app look
- Space Grotesk for headings, Inter for body/UI text
- Mobile-first: single column, max 480px content width, horizontal snap-scrolling rows, fixed bottom nav

## Running this from your Android phone

You don't need a laptop — pick one of these:

### Option A — StackBlitz (easiest, fully in-browser)
1. Zip is attached to this chat — unzip it to a folder using a file manager app (most Android file managers can unzip natively).
2. Go to **stackblitz.com** in Chrome, tap **Create → Import Project**, and upload the unzipped folder (or push it to GitHub first and import via the repo URL — see Option B).
3. StackBlitz installs dependencies and runs the dev server automatically in-browser. No install needed.

### Option B — GitHub + StackBlitz/CodeSandbox
1. Install the **GitHub** app (or use github.com in Chrome), create a new repo, and upload the project files.
2. Open `stackblitz.com/github/<your-username>/<repo-name>` or `codesandbox.io/s/github/<your-username>/<repo-name>` — it will build and preview automatically.

### Option C — Termux (real terminal on-device)
1. Install **Termux** from F-Droid (not the outdated Play Store version).
2. In Termux: `pkg install nodejs`
3. Unzip the project into Termux's storage, `cd` into the `xstream` folder, then:
   ```
   npm install
   npm run dev -- --host
   ```
4. Open the printed `http://localhost:5173` (or the LAN IP shown) in Chrome on the same device.

## Standard commands (any environment with Node 18+)

```bash
npm install       # install dependencies
npm run dev        # start dev server
npm run build       # production build
npm run preview     # preview the production build
```

## Note on this build

This project was scaffolded in a sandbox without internet access, so `npm install` hasn't been run or verified here — the code was written carefully against known-stable versions of Vite, React Router, and lucide-react, but please run `npm install` yourself as the first step wherever you continue, and let me know if anything doesn't compile.

## Next steps to build out

- Wire up real routes/content for Movies, Music, Live TV, News, Search, Favorites, Profile
- Add a search implementation (filter mock data, or connect a real API later)
- Add favorites state (localStorage or a backend)
- Replace gradient placeholders with real artwork once you have licensed/owned assets
