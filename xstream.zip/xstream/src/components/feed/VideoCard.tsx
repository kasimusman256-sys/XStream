import { useEffect, useRef, useState } from 'react'
import { Play, Volume2, VolumeX } from 'lucide-react'
import type { Video } from '../../types'
import ActionColumn from './ActionColumn'
import VideoInfo from './VideoInfo'
import ProgressBar from './ProgressBar'

interface Props {
  video: Video
  isActive: boolean
  muted: boolean
  onToggleMute: () => void
  setRef: (el: HTMLDivElement | null) => void
}

export default function VideoCard({ video, isActive, muted, onToggleMute, setRef }: Props) {
  const [paused, setPaused] = useState(false)
  const [following, setFollowing] = useState(false)
  const [liked, setLiked] = useState(video.likedByUser)
  const [favorited, setFavorited] = useState(video.favoritedByUser)
  const [likeCount, setLikeCount] = useState(video.stats.likes)
  const [favoriteCount, setFavoriteCount] = useState(video.stats.favorites)
  const [progress, setProgress] = useState(0)
  const intervalRef = useRef<number | null>(null)

  const playing = isActive && !paused

  // Reset & drive the simulated progress bar only while this card is active
  useEffect(() => {
    if (!isActive) {
      setProgress(0)
      setPaused(false)
    }
  }, [isActive])

  useEffect(() => {
    if (intervalRef.current) window.clearInterval(intervalRef.current)
    if (!playing) return

    const stepMs = 200
    const totalSteps = (video.durationSeconds * 1000) / stepMs
    intervalRef.current = window.setInterval(() => {
      setProgress((p) => (p + 1 / totalSteps >= 1 ? 0 : p + 1 / totalSteps))
    }, stepMs)

    return () => {
      if (intervalRef.current) window.clearInterval(intervalRef.current)
    }
  }, [playing, video.durationSeconds])

  return (
    <div
      ref={setRef}
      data-video-id={video.id}
      style={{
        position: 'relative',
        height: '100dvh',
        width: '100%',
        scrollSnapAlign: 'start',
        scrollSnapStop: 'always',
        overflow: 'hidden',
        background: video.gradient,
      }}
      onClick={() => setPaused((p) => !p)}
    >
      {/* Simulated "video" motion layer — no real video files are used */}
      <div
        style={{
          position: 'absolute',
          inset: '-10%',
          background:
            'radial-gradient(circle at 30% 20%, rgba(255,255,255,0.07), transparent 55%), radial-gradient(circle at 75% 80%, rgba(255,255,255,0.05), transparent 50%)',
          animation: 'ambientDrift 14s ease-in-out infinite',
          animationPlayState: playing ? 'running' : 'paused',
        }}
      />

      {/* Demo watermark so it reads clearly as placeholder art, not a real clip */}
      <span
        style={{
          position: 'absolute',
          top: 14,
          left: 14,
          fontSize: 11,
          fontWeight: 600,
          letterSpacing: '0.04em',
          color: 'rgba(242,240,234,0.45)',
        }}
      >
        DEMO CLIP
      </span>

      {!playing && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <div
            style={{
              width: 64,
              height: 64,
              borderRadius: '50%',
              background: 'rgba(0,0,0,0.4)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Play size={28} color="#fff" fill="#fff" />
          </div>
        </div>
      )}

      <button
        onClick={(e) => {
          e.stopPropagation()
          onToggleMute()
        }}
        aria-label={muted ? 'Unmute' : 'Mute'}
        style={{
          position: 'absolute',
          top: 14,
          right: 14,
          width: 34,
          height: 34,
          borderRadius: '50%',
          background: 'rgba(0,0,0,0.4)',
          border: 'none',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 6,
        }}
      >
        {muted ? <VolumeX size={17} color="#fff" /> : <Volume2 size={17} color="#fff" />}
      </button>

      <VideoInfo video={video} following={following} onFollow={() => setFollowing(true)} />

      <ActionColumn
        avatarGradient={video.creator.avatarGradient}
        stats={{ ...video.stats, likes: likeCount, favorites: favoriteCount }}
        liked={liked}
        favorited={favorited}
        following={following}
        onLike={() => {
          setLiked((v) => !v)
          setLikeCount((c) => (liked ? c - 1 : c + 1))
        }}
        onFavorite={() => {
          setFavorited((v) => !v)
          setFavoriteCount((c) => (favorited ? c - 1 : c + 1))
        }}
        onFollow={() => setFollowing((v) => !v)}
        onComment={() => {}}
        onShare={() => {}}
      />

      <ProgressBar progress={progress} />
    </div>
  )
}
