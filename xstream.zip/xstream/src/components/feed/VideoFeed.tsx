import { useEffect, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import type { Video } from '../../types'
import VideoCard from './VideoCard'

interface Props {
  videos: Video[]
  /** Shown when the videos array is empty (e.g. an empty Following feed) */
  emptyState?: ReactNode
}

export default function VideoFeed({ videos, emptyState }: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null)
  const cardRefs = useRef<Map<string, HTMLDivElement>>(new Map())
  const [activeId, setActiveId] = useState<string | null>(videos[0]?.id ?? null)
  const [muted, setMuted] = useState(true)

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const observer = new IntersectionObserver(
      (entries) => {
        // Pick the entry with the greatest visible ratio — keeps exactly
        // one video "active" (playing) at a time during the snap-scroll.
        let best: IntersectionObserverEntry | null = null
        for (const entry of entries) {
          if (entry.isIntersecting && (!best || entry.intersectionRatio > best.intersectionRatio)) {
            best = entry
          }
        }
        if (best) {
          const id = (best.target as HTMLElement).dataset.videoId
          if (id) setActiveId(id)
        }
      },
      { root: container, threshold: [0.6] }
    )

    cardRefs.current.forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [videos])

  if (videos.length === 0 && emptyState) {
    return (
      <div style={{ height: '100dvh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {emptyState}
      </div>
    )
  }

  return (
    <div ref={containerRef} className="video-feed">
      {videos.map((video) => (
        <VideoCard
          key={video.id}
          video={video}
          isActive={video.id === activeId}
          muted={muted}
          onToggleMute={() => setMuted((m) => !m)}
          setRef={(el) => {
            if (el) cardRefs.current.set(video.id, el)
            else cardRefs.current.delete(video.id)
          }}
        />
      ))}
    </div>
  )
}
