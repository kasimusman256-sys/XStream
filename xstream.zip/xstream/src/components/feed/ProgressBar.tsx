interface Props {
  progress: number // 0 to 1
}

export default function ProgressBar({ progress }: Props) {
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 0,
        height: 3,
        background: 'rgba(255,255,255,0.18)',
        zIndex: 6,
      }}
    >
      <div
        style={{
          height: '100%',
          width: `${Math.min(progress, 1) * 100}%`,
          background: 'var(--accent)',
          transition: 'width 0.2s linear',
        }}
      />
    </div>
  )
}
