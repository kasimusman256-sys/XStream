import { Music2 } from 'lucide-react'
import type { Video } from '../../types'

interface Props {
  video: Video
  following: boolean
  onFollow: () => void
}

export default function VideoInfo({ video, following, onFollow }: Props) {
  return (
    <div
      style={{
        position: 'absolute',
        left: 14,
        right: 78,
        bottom: 90,
        color: '#fff',
        zIndex: 5,
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <span style={{ fontWeight: 700, fontSize: 15, textShadow: '0 1px 3px rgba(0,0,0,0.6)' }}>
          {video.creator.username}
        </span>
        {!following && (
          <button
            onClick={(e) => {
              e.stopPropagation()
              onFollow()
            }}
            style={{
              fontSize: 12,
              fontWeight: 700,
              color: 'var(--accent)',
              background: 'rgba(0,0,0,0.35)',
              border: '1px solid var(--accent)',
              borderRadius: 6,
              padding: '2px 8px',
            }}
          >
            Follow
          </button>
        )}
      </div>

      <p style={{ fontSize: 14, fontWeight: 600, margin: '0 0 4px', textShadow: '0 1px 3px rgba(0,0,0,0.6)' }}>
        {video.title}
      </p>
      <p style={{ fontSize: 13, color: 'rgba(242,240,234,0.85)', margin: '0 0 6px', textShadow: '0 1px 3px rgba(0,0,0,0.6)' }}>
        {video.description}
      </p>
      <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--accent-strong)', margin: '0 0 8px' }}>
        {video.hashtags.join('  ')}
      </p>

      <div style={{ display: 'flex', alignItems: 'center', gap: 6, opacity: 0.9 }}>
        <Music2 size={13} />
        <span
          style={{
            fontSize: 12,
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            maxWidth: 200,
          }}
        >
          {video.musicName}
        </span>
      </div>
    </div>
  )
}
