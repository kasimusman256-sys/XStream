import type { ReactNode } from 'react'
import { Heart, MessageCircle, Share2, Star, Plus, Check } from 'lucide-react'
import type { VideoStats } from '../../types'
import { formatCount } from '../../utils/format'

interface Props {
  avatarGradient: string
  stats: VideoStats
  liked: boolean
  favorited: boolean
  following: boolean
  onLike: () => void
  onFavorite: () => void
  onFollow: () => void
  onComment: () => void
  onShare: () => void
}

function ActionButton({
  onClick,
  active,
  activeColor,
  label,
  children,
}: {
  onClick: () => void
  active?: boolean
  activeColor?: string
  label: string
  children: ReactNode
}) {
  return (
    <button
      onClick={(e) => {
        e.stopPropagation()
        onClick()
      }}
      aria-label={label}
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 4,
        background: 'transparent',
        border: 'none',
        color: active ? activeColor ?? 'var(--accent)' : '#fff',
      }}
    >
      {children}
    </button>
  )
}

export default function ActionColumn({
  avatarGradient,
  stats,
  liked,
  favorited,
  following,
  onLike,
  onFavorite,
  onFollow,
  onComment,
  onShare,
}: Props) {
  return (
    <div
      style={{
        position: 'absolute',
        right: 10,
        bottom: 96,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 20,
        zIndex: 5,
      }}
    >
      {/* avatar + follow badge */}
      <div style={{ position: 'relative', marginBottom: 4 }}>
        <div
          style={{
            width: 46,
            height: 46,
            borderRadius: '50%',
            background: avatarGradient,
            border: '2px solid #fff',
          }}
        />
        {!following && (
          <button
            onClick={(e) => {
              e.stopPropagation()
              onFollow()
            }}
            aria-label="Follow creator"
            style={{
              position: 'absolute',
              bottom: -8,
              left: '50%',
              transform: 'translateX(-50%)',
              width: 20,
              height: 20,
              borderRadius: '50%',
              background: 'var(--accent)',
              border: 'none',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Plus size={13} color="#171000" strokeWidth={3} />
          </button>
        )}
      </div>

      <ActionButton onClick={onLike} active={liked} activeColor="var(--live)" label="Like">
        <Heart size={30} fill={liked ? 'var(--live)' : 'none'} />
        <span style={{ fontSize: 12, fontWeight: 600, textShadow: '0 1px 3px rgba(0,0,0,0.6)' }}>
          {formatCount(stats.likes)}
        </span>
      </ActionButton>

      <ActionButton onClick={onComment} label="Comments">
        <MessageCircle size={28} />
        <span style={{ fontSize: 12, fontWeight: 600, textShadow: '0 1px 3px rgba(0,0,0,0.6)' }}>
          {formatCount(stats.comments)}
        </span>
      </ActionButton>

      <ActionButton onClick={onFavorite} active={favorited} activeColor="var(--accent)" label="Favorite">
        <Star size={28} fill={favorited ? 'var(--accent)' : 'none'} />
        <span style={{ fontSize: 12, fontWeight: 600, textShadow: '0 1px 3px rgba(0,0,0,0.6)' }}>
          {formatCount(stats.favorites)}
        </span>
      </ActionButton>

      <ActionButton onClick={onShare} label="Share">
        <Share2 size={27} />
        <span style={{ fontSize: 12, fontWeight: 600, textShadow: '0 1px 3px rgba(0,0,0,0.6)' }}>
          {formatCount(stats.shares)}
        </span>
      </ActionButton>

      {following && (
        <ActionButton onClick={onFollow} active label="Following">
          <Check size={24} />
        </ActionButton>
      )}
    </div>
  )
}
