export default function LiveBadge() {
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 4,
        fontSize: 10,
        fontWeight: 700,
        color: '#fff',
        background: 'var(--live)',
        borderRadius: 4,
        padding: '2px 6px',
        letterSpacing: '0.02em',
      }}
    >
      <span
        style={{
          width: 5,
          height: 5,
          borderRadius: '50%',
          background: '#fff',
        }}
      />
      Live
    </span>
  )
}
