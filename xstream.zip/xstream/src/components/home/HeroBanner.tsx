import { Play, Plus } from 'lucide-react'
import type { ContentItem } from '../../types'

export default function HeroBanner({ item }: { item: ContentItem }) {
  return (
    <div
      style={{
        margin: '0 16px 24px',
        borderRadius: 'var(--radius-md)',
        overflow: 'hidden',
        background: item.gradient,
        border: '1px solid var(--border)',
        position: 'relative',
      }}
    >
      <div style={{ padding: '28px 18px 18px', minHeight: 200, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
        {item.tag && (
          <span
            style={{
              alignSelf: 'flex-start',
              fontSize: 11,
              fontWeight: 600,
              color: 'var(--accent-strong)',
              marginBottom: 10,
            }}
          >
            {item.tag}
          </span>
        )}
        <h1 style={{ fontSize: 26, lineHeight: 1.15, marginBottom: 8, maxWidth: '80%' }}>
          {item.title}
        </h1>
        {item.subtitle && (
          <p style={{ color: 'var(--text-muted)', fontSize: 14, marginBottom: 18, maxWidth: '90%' }}>
            {item.subtitle}
          </p>
        )}
        <div style={{ display: 'flex', gap: 10 }}>
          <button
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              background: 'var(--accent)',
              color: '#171000',
              border: 'none',
              borderRadius: 8,
              padding: '10px 18px',
              fontWeight: 700,
              fontSize: 14,
            }}
          >
            <Play size={16} fill="#171000" /> Play
          </button>
          <button
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              background: 'rgba(255,255,255,0.08)',
              color: 'var(--text)',
              border: '1px solid var(--border)',
              borderRadius: 8,
              padding: '10px 16px',
              fontWeight: 600,
              fontSize: 14,
            }}
          >
            <Plus size={16} /> My List
          </button>
        </div>
      </div>
    </div>
  )
}
