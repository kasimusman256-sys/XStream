import type { ContentItem } from '../../types'
import ContentCard from './ContentCard'

interface Props {
  title: string
  items: ContentItem[]
  wide?: boolean
}

export default function ContentRow({ title, items, wide }: Props) {
  if (items.length === 0) return null

  return (
    <section style={{ marginBottom: 26 }}>
      <h2 style={{ fontSize: 16, padding: '0 16px', marginBottom: 12 }}>{title}</h2>
      <div className="scroll-row">
        {items.map((item) => (
          <ContentCard key={item.id} item={item} wide={wide} />
        ))}
      </div>
    </section>
  )
}
