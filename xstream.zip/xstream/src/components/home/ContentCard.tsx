import type { ContentItem } from '../../types'
import LiveBadge from './LiveBadge'

interface Props {
  item: ContentItem
  wide?: boolean
}

export default function ContentCard({ item, wide }: Props) {
  const width = wide ? 168 : 122

  return (
    <button
      style={{
        flex: `0 0 ${width}px`,
        scrollSnapAlign: 'start',
        background: 'transparent',
        border: 'none',
        padding: 0,
        textAlign: 'left',
        color: 'var(--text)',
      }}
    >
      <div
        style={{
          width,
          height: wide ? 94 : 168,
          borderRadius: 'var(--radius-sm)',
          background: item.gradient,
          border: '1px solid var(--border)',
          position: 'relative',
          marginBottom: 8,
          overflow: 'hidden',
        }}
      >
        {item.isLive && (
          <div style={{ position: 'absolute', top: 6, left: 6 }}>
            <LiveBadge />
          </div>
        )}
        {item.duration && (
          <span
            style={{
              position: 'absolute',
              bottom: 6,
              right: 6,
              fontSize: 10,
              background: 'rgba(0,0,0,0.55)',
              padding: '2px 5px',
              borderRadius: 4,
              color: 'var(--text-muted)',
            }}
          >
            {item.duration}
          </span>
        )}
      </div>
      <p
        style={{
          fontSize: 13,
          fontWeight: 600,
          lineHeight: 1.3,
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
        }}
      >
        {item.title}
      </p>
      {item.subtitle && (
        <p
          style={{
            fontSize: 12,
            color: 'var(--text-muted)',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}
        >
          {item.subtitle}
        </p>
      )}
    </button>
  )
}
