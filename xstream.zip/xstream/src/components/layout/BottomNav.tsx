import { NavLink } from 'react-router-dom'
import type { LucideIcon } from 'lucide-react'
import { Home, Compass, Plus, Users, User } from 'lucide-react'

const tabs = [
  { to: '/', label: 'Home', icon: Home, end: true },
  { to: '/discover', label: 'Discover', icon: Compass, end: false },
  { to: '/following', label: 'Following', icon: Users, end: false },
  { to: '/profile', label: 'Profile', icon: User, end: false },
]

export default function BottomNav() {
  return (
    <nav
      style={{
        position: 'fixed',
        bottom: 0,
        left: '50%',
        transform: 'translateX(-50%)',
        width: '100%',
        maxWidth: 480,
        height: 'var(--nav-height)',
        display: 'flex',
        alignItems: 'center',
        background: 'rgba(15,20,23,0.75)',
        backdropFilter: 'blur(10px)',
        borderTop: '1px solid var(--border)',
        paddingBottom: 'env(safe-area-inset-bottom)',
        zIndex: 20,
      }}
    >
      {tabs.slice(0, 2).map((tab) => (
        <NavTab key={tab.to} {...tab} />
      ))}

      {/* Create — visually distinct, elevated action */}
      <NavLink
        to="/create"
        aria-label="Create"
        style={{ flex: 1, display: 'flex', justifyContent: 'center' }}
      >
        <div
          style={{
            width: 42,
            height: 30,
            borderRadius: 8,
            background: 'var(--accent)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Plus size={20} color="#171000" strokeWidth={2.6} />
        </div>
      </NavLink>

      {tabs.slice(2).map((tab) => (
        <NavTab key={tab.to} {...tab} />
      ))}
    </nav>
  )
}

function NavTab({
  to,
  label,
  icon: Icon,
  end,
}: {
  to: string
  label: string
  icon: LucideIcon
  end: boolean
}) {
  return (
    <NavLink
      to={to}
      end={end}
      style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 4,
        fontSize: 11,
      }}
    >
      {({ isActive }) => (
        <>
          <Icon
            size={21}
            color={isActive ? 'var(--accent)' : '#fff'}
            strokeWidth={isActive ? 2.4 : 2}
          />
          <span style={{ color: isActive ? 'var(--accent)' : 'rgba(255,255,255,0.85)' }}>
            {label}
          </span>
        </>
      )}
    </NavLink>
  )
}
