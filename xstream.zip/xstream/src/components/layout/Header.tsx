import { Link } from 'react-router-dom'
import { Cast } from 'lucide-react'
import { demoUser } from '../../data/mockData'

export default function Header() {
  return (
    <header
      style={{
        position: 'fixed',
        top: 0,
        left: '50%',
        transform: 'translateX(-50%)',
        width: '100%',
        maxWidth: 480,
        height: 'var(--header-height)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 16px',
        background: 'rgba(15,20,23,0.92)',
        backdropFilter: 'blur(10px)',
        borderBottom: '1px solid var(--border)',
        zIndex: 20,
      }}
    >
      <Link
        to="/"
        style={{
          fontFamily: 'var(--font-display)',
          fontWeight: 700,
          fontSize: 20,
          letterSpacing: '-0.02em',
        }}
      >
        X<span style={{ color: 'var(--accent)' }}>Stream</span>
      </Link>

      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <Cast size={20} color="var(--text-muted)" aria-label="Cast" />
        <Link to="/profile" aria-label="Profile">
          <div
            style={{
              width: 30,
              height: 30,
              borderRadius: '50%',
              background: demoUser.avatarGradient,
              border: '1px solid var(--border)',
            }}
          />
        </Link>
      </div>
    </header>
  )
}
