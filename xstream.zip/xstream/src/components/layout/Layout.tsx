import { Outlet, useLocation } from 'react-router-dom'
import Header from './Header'
import BottomNav from './BottomNav'

export default function Layout() {
  const { pathname } = useLocation()
  // Home and Following are immersive full-bleed video feeds: no top header,
  // no content padding — video fills the screen behind the floating bottom nav.
  const isImmersive = pathname === '/' || pathname === '/following'

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        maxWidth: 480,
        margin: '0 auto',
        position: 'relative',
        background: 'var(--bg)',
      }}
    >
      {!isImmersive && <Header />}
      <main
        style={{
          flex: 1,
          paddingTop: isImmersive ? 0 : 'var(--header-height)',
          paddingBottom: isImmersive ? 0 : 'calc(var(--nav-height) + 16px)',
        }}
      >
        <Outlet />
      </main>
      <BottomNav />
    </div>
  )
}
