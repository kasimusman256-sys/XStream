export type ContentKind = 'movie' | 'music' | 'live' | 'news'

export interface ContentItem {
  id: string
  kind: ContentKind
  title: string
  subtitle?: string
  /** CSS gradient used as placeholder art — no real poster/cover assets */
  gradient: string
  duration?: string
  year?: number
  tag?: string
  isLive?: boolean
}

export interface Creator {
  id: string
  username: string
  displayName: string
  avatarGradient: string
  followerCount: number
  bio?: string
}

export interface VideoStats {
  likes: number
  comments: number
  shares: number
  favorites: number
}

export interface Video {
  id: string
  creator: Creator
  title: string
  description: string
  hashtags: string[]
  musicName: string
  /** CSS gradient standing in for the video frame — no real video files are bundled */
  gradient: string
  /** total demo playback length, used to drive the simulated progress bar */
  durationSeconds: number
  stats: VideoStats
  likedByUser: boolean
  favoritedByUser: boolean
}

export interface UserProfile {
  name: string
  handle: string
  plan: string
  avatarGradient: string
  bio: string
  followers: number
  following: number
  likes: number
}
