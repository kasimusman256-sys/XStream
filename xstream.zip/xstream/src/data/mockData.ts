import type { ContentItem, Creator, UserProfile, Video } from '../types'

// All names, titles, and handles below are original placeholders invented
// for this demo. Swap this file for a real API/catalog integration later.

// ---------------------------------------------------------------------------
// Creators
// ---------------------------------------------------------------------------

export const creators: Creator[] = [
  {
    id: 'cr-1',
    username: '@rivera.codes',
    displayName: 'Alex Rivera',
    avatarGradient: 'linear-gradient(135deg,#e8a33d,#e8496b)',
    followerCount: 128000,
    bio: 'Building small things in public. Coffee-powered.',
  },
  {
    id: 'cr-2',
    username: '@coastlinekit',
    displayName: 'Coastline Kit',
    avatarGradient: 'linear-gradient(135deg,#4fd1c5,#1e3a34)',
    followerCount: 84200,
    bio: 'Van life, tide charts, and bad puns.',
  },
  {
    id: 'cr-3',
    username: '@novafreq',
    displayName: 'Nova Frequency',
    avatarGradient: 'linear-gradient(135deg,#8b5cf6,#241e3a)',
    followerCount: 341000,
    bio: 'DJ sets, studio sessions, late nights.',
  },
  {
    id: 'cr-4',
    username: '@paperlanterns',
    displayName: 'Paper Lanterns Studio',
    avatarGradient: 'linear-gradient(135deg,#f2b458,#3a2a1e)',
    followerCount: 52700,
    bio: 'Stop-motion shorts, one frame at a time.',
  },
  {
    id: 'cr-5',
    username: '@lowtidecity',
    displayName: 'Low Tide City',
    avatarGradient: 'linear-gradient(135deg,#22a3a3,#101619)',
    followerCount: 19800,
    bio: 'Skate clips from around the harbor.',
  },
]

// Demo-only: creators the signed-in user already follows (no backend yet)
export const followedCreatorIds: string[] = ['cr-2', 'cr-3']

// ---------------------------------------------------------------------------
// Videos — the vertical feed
// ---------------------------------------------------------------------------

export const videos: Video[] = [
  {
    id: 'vid-1',
    creator: creators[0],
    title: 'Rebuilding a login form in 60 seconds',
    description: 'Small refactor, big readability win. Full walkthrough on the channel.',
    hashtags: ['#buildinpublic', '#webdev', '#xstream'],
    musicName: 'Original audio — rivera.codes',
    gradient: 'linear-gradient(160deg,#22323a 0%,#101619 55%,#1c2b33 100%)',
    durationSeconds: 42,
    stats: { likes: 18400, comments: 342, shares: 512, favorites: 980 },
    likedByUser: false,
    favoritedByUser: false,
  },
  {
    id: 'vid-2',
    creator: creators[1],
    title: 'Low tide at 6am hits different',
    description: 'Parked here for the night. Coffee, fog, and nowhere to be.',
    hashtags: ['#vanlife', '#coastline', '#slowmornings'],
    musicName: 'Coastline Choir — Harbor Light',
    gradient: 'linear-gradient(160deg,#1e3a34 0%,#0f1417 55%,#144038 100%)',
    durationSeconds: 28,
    stats: { likes: 92100, comments: 1204, shares: 3300, favorites: 5100 },
    likedByUser: true,
    favoritedByUser: false,
  },
  {
    id: 'vid-3',
    creator: creators[2],
    title: 'New drop — 30 second preview',
    description: 'Full track out Friday. This is the bridge section, unmixed.',
    hashtags: ['#novafrequency', '#newmusic', '#deephouse'],
    musicName: 'Nova Frequency — Untitled (Bridge)',
    gradient: 'linear-gradient(160deg,#241e3a 0%,#101017 55%,#33244a 100%)',
    durationSeconds: 30,
    stats: { likes: 204000, comments: 4800, shares: 12100, favorites: 26400 },
    likedByUser: false,
    favoritedByUser: true,
  },
  {
    id: 'vid-4',
    creator: creators[3],
    title: 'Paper crane army, frame by frame',
    description: '1,200 photos for 8 seconds of animation. Worth it.',
    hashtags: ['#stopmotion', '#paperlanterns', '#animation'],
    musicName: 'Original audio — paperlanterns',
    gradient: 'linear-gradient(160deg,#3a2a1e 0%,#171008 55%,#4a331e 100%)',
    durationSeconds: 19,
    stats: { likes: 61200, comments: 890, shares: 2040, favorites: 4300 },
    likedByUser: false,
    favoritedByUser: false,
  },
  {
    id: 'vid-5',
    creator: creators[4],
    title: 'Sunset session at the old pier',
    description: 'Third try was the charm. Full clip on the profile.',
    hashtags: ['#skate', '#lowtidecity', '#goldenhour'],
    musicName: 'Static & Bloom — Amber Rail',
    gradient: 'linear-gradient(160deg,#22a3a3 0%,#0c1a1a 55%,#154343 100%)',
    durationSeconds: 24,
    stats: { likes: 33900, comments: 511, shares: 940, favorites: 1600 },
    likedByUser: false,
    favoritedByUser: false,
  },
]

// ---------------------------------------------------------------------------
// Discover — reused rows from the original catalog layout
// ---------------------------------------------------------------------------

export const trendingMovies: ContentItem[] = [
  { id: 'mv-1', kind: 'movie', title: 'Glass Horizon', year: 2026, gradient: 'linear-gradient(135deg,#22323a,#101619)' },
  { id: 'mv-2', kind: 'movie', title: 'Nine Rivers', year: 2025, gradient: 'linear-gradient(135deg,#3a2422,#101619)' },
  { id: 'mv-3', kind: 'movie', title: 'Paper Lanterns', year: 2024, gradient: 'linear-gradient(135deg,#243a2c,#101619)' },
  { id: 'mv-4', kind: 'movie', title: 'Concrete Bloom', year: 2026, gradient: 'linear-gradient(135deg,#33243a,#101619)' },
  { id: 'mv-5', kind: 'movie', title: 'The Quiet Engine', year: 2023, gradient: 'linear-gradient(135deg,#3a3222,#101619)' },
  { id: 'mv-6', kind: 'movie', title: 'Low Tide City', year: 2025, gradient: 'linear-gradient(135deg,#223a38,#101619)' },
]

export const musicPicks: ContentItem[] = [
  { id: 'mu-1', kind: 'music', title: 'Midnight Runners', subtitle: 'Synth / Electronic', gradient: 'linear-gradient(135deg,#3a1e33,#101619)' },
  { id: 'mu-2', kind: 'music', title: 'Coastline Choir', subtitle: 'Indie Folk', gradient: 'linear-gradient(135deg,#1e3a34,#101619)' },
  { id: 'mu-3', kind: 'music', title: 'Static & Bloom', subtitle: 'Alt Rock', gradient: 'linear-gradient(135deg,#3a2a1e,#101619)' },
  { id: 'mu-4', kind: 'music', title: 'Nova Frequency', subtitle: 'Deep House', gradient: 'linear-gradient(135deg,#1e253a,#101619)' },
  { id: 'mu-5', kind: 'music', title: 'The Loft Sessions', subtitle: 'Jazz', gradient: 'linear-gradient(135deg,#3a1e1e,#101619)' },
]

export const liveChannels: ContentItem[] = [
  { id: 'lv-1', kind: 'live', title: 'XStream Sports 1', subtitle: 'Regional Finals', gradient: 'linear-gradient(135deg,#3a1e24,#101619)', isLive: true },
  { id: 'lv-2', kind: 'live', title: 'Pulse Music TV', subtitle: 'Top 40 Countdown', gradient: 'linear-gradient(135deg,#241e3a,#101619)', isLive: true },
  { id: 'lv-3', kind: 'live', title: 'Horizon Docs', subtitle: 'Deep Sea Season', gradient: 'linear-gradient(135deg,#1e3a2e,#101619)', isLive: true },
  { id: 'lv-4', kind: 'live', title: 'Kids Circuit', subtitle: 'Afternoon Block', gradient: 'linear-gradient(135deg,#3a331e,#101619)', isLive: true },
]

export const newsHeadlines: ContentItem[] = [
  { id: 'nw-1', kind: 'news', title: 'City council approves new transit line', subtitle: 'Local · 3h ago', gradient: 'linear-gradient(135deg,#22242e,#101619)' },
  { id: 'nw-2', kind: 'news', title: 'Markets steady after quarterly earnings wave', subtitle: 'Business · 5h ago', gradient: 'linear-gradient(135deg,#242e22,#101619)' },
  { id: 'nw-3', kind: 'news', title: 'Coastal towns prepare for storm season', subtitle: 'Weather · 7h ago', gradient: 'linear-gradient(135deg,#2e2422,#101619)' },
  { id: 'nw-4', kind: 'news', title: 'Regional league announces finals schedule', subtitle: 'Sports · 9h ago', gradient: 'linear-gradient(135deg,#22282e,#101619)' },
]

// ---------------------------------------------------------------------------
// Signed-in demo user
// ---------------------------------------------------------------------------

export const demoUser: UserProfile = {
  name: 'Alex Rivera',
  handle: '@rivera.codes',
  plan: 'Premium plan',
  avatarGradient: 'linear-gradient(135deg,#e8a33d,#e8496b)',
  bio: 'Building small things in public. Coffee-powered.',
  followers: 128000,
  following: 214,
  likes: 942000,
}
