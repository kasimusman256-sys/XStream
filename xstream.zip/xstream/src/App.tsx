import { Routes, Route } from 'react-router-dom'
import Layout from './components/layout/Layout'
import Home from './pages/Home'
import Discover from './pages/Discover'
import Create from './pages/Create'
import Following from './pages/Following'
import Profile from './pages/Profile'
import Movies from './pages/Movies'
import Music from './pages/Music'
import LiveTV from './pages/LiveTV'
import News from './pages/News'
import Search from './pages/Search'
import Favorites from './pages/Favorites'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/discover" element={<Discover />} />
        <Route path="/create" element={<Create />} />
        <Route path="/following" element={<Following />} />
        <Route path="/profile" element={<Profile />} />

        {/* Kept from the original catalog layout — still reachable, not in the
            main tab bar now that Discover surfaces this content instead. */}
        <Route path="/movies" element={<Movies />} />
        <Route path="/music" element={<Music />} />
        <Route path="/live" element={<LiveTV />} />
        <Route path="/news" element={<News />} />
        <Route path="/search" element={<Search />} />
        <Route path="/favorites" element={<Favorites />} />
      </Route>
    </Routes>
  )
}
