import VideoFeed from '../components/feed/VideoFeed'
import { videos } from '../data/mockData'

export default function Home() {
  return <VideoFeed videos={videos} />
}
