import { Link } from 'react-router-dom'
import ContentRow from '../components/home/ContentRow'
import { formatCount } from '../utils/format'
import {
  videos,
  creators,
  trendingMovies,
  musicPicks,
  liveChannels,
  newsHeadlines,
} from '../data/mockData'

export default function Discover() {
  return (
    <div style={{ paddingTop: 16 }}>
      <h1 style={{ fontSize: 20, padding: '0 16px', marginBottom: 14 }}>Discover</h1>

      {/* Trending videos — 3-column grid linking back to the vertical feed */}
      <section style={{ marginBottom: 26 }}>
        <h2 style={{ fontSize: 16, padding: '0 16px', marginBottom: 12 }}>Trending Videos</h2>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: 6,
            padding: '0 16px',
          }}
        >
          {videos.map((v) => (
            <Link
              key={v.id}
              to="/"
              style={{
                aspectRatio: '9 / 16',
                borderRadius: 8,
                background: v.gradient,
                border: '1px solid var(--border)',
                position: 'relative',
                overflow: 'hidden',
                display: 'block',
              }}
            >
              <span
                style={{
                  position: 'absolute',
                  left: 6,
                  bottom: 6,
                  right: 6,
                  fontSize: 11,
                  color: '#fff',
                  fontWeight: 600,
                  textShadow: '0 1px 3px rgba(0,0,0,0.7)',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                }}
              >
                ♥ {formatCount(v.stats.likes)}
              </span>
            </Link>
          ))}
        </div>
      </section>

      <ContentRow title="Trending Movies" items={trendingMovies} />
      <ContentRow title="Music For You" items={musicPicks} />
      <ContentRow title="Live Now" items={liveChannels} wide />
      <ContentRow title="Top Headlines" items={newsHeadlines} wide />

      {/* Creators */}
      <section style={{ marginBottom: 12 }}>
        <h2 style={{ fontSize: 16, padding: '0 16px', marginBottom: 12 }}>Creators to Follow</h2>
        <div className="scroll-row">
          {creators.map((c) => (
            <div
              key={c.id}
              style={{
                flex: '0 0 108px',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                textAlign: 'center',
                gap: 6,
              }}
            >
              <div
                style={{
                  width: 60,
                  height: 60,
                  borderRadius: '50%',
                  background: c.avatarGradient,
                  border: '1px solid var(--border)',
                }}
              />
              <p style={{ fontSize: 12, fontWeight: 600, margin: 0 }}>{c.username}</p>
              <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: 0 }}>
                {formatCount(c.followerCount)} followers
              </p>
              <button
                style={{
                  fontSize: 11,
                  fontWeight: 700,
                  color: '#171000',
                  background: 'var(--accent)',
                  border: 'none',
                  borderRadius: 6,
                  padding: '4px 10px',
                }}
              >
                Follow
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
