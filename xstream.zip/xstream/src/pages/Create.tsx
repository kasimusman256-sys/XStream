import { useState } from 'react'
import type { CSSProperties } from 'react'
import { UploadCloud, Check } from 'lucide-react'

const thumbnailOptions = [
  'linear-gradient(160deg,#22323a,#101619)',
  'linear-gradient(160deg,#3a2a1e,#171008)',
  'linear-gradient(160deg,#241e3a,#101017)',
  'linear-gradient(160deg,#1e3a34,#0f1417)',
  'linear-gradient(160deg,#22a3a3,#0c1a1a)',
  'linear-gradient(160deg,#3a1e24,#101619)',
]

const inputStyle: CSSProperties = {
  width: '100%',
  background: 'var(--surface)',
  border: '1px solid var(--border)',
  borderRadius: 8,
  color: 'var(--text)',
  padding: '10px 12px',
  fontSize: 14,
  fontFamily: 'var(--font-body)',
}

export default function Create() {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [hashtags, setHashtags] = useState('')
  const [thumbnail, setThumbnail] = useState(thumbnailOptions[0])
  const [published, setPublished] = useState(false)

  const canPublish = title.trim().length > 0

  if (published) {
    return (
      <div style={{ padding: '60px 24px', textAlign: 'center' }}>
        <div
          style={{
            width: 56,
            height: 56,
            borderRadius: '50%',
            background: 'var(--accent)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 16px',
          }}
        >
          <Check size={28} color="#171000" />
        </div>
        <h1 style={{ fontSize: 18, marginBottom: 8 }}>Video published</h1>
        <p style={{ color: 'var(--text-muted)', fontSize: 14, marginBottom: 20 }}>
          This is a demo upload — no file was actually sent anywhere. Hook this
          screen up to a real backend when you're ready.
        </p>
        <button
          onClick={() => {
            setPublished(false)
            setTitle('')
            setDescription('')
            setHashtags('')
            setThumbnail(thumbnailOptions[0])
          }}
          style={{
            background: 'var(--surface-elevated)',
            color: 'var(--text)',
            border: '1px solid var(--border)',
            borderRadius: 8,
            padding: '10px 18px',
            fontSize: 14,
            fontWeight: 600,
          }}
        >
          Upload another
        </button>
      </div>
    )
  }

  return (
    <div style={{ padding: '20px 16px 40px' }}>
      <h1 style={{ fontSize: 20, marginBottom: 4 }}>Create</h1>
      <p style={{ color: 'var(--text-muted)', fontSize: 13, marginBottom: 20 }}>
        Demo upload — nothing leaves your device yet.
      </p>

      {/* Fake file drop zone */}
      <div
        style={{
          border: '1.5px dashed var(--border)',
          borderRadius: 10,
          padding: '28px 16px',
          textAlign: 'center',
          marginBottom: 20,
        }}
      >
        <UploadCloud size={26} color="var(--text-muted)" style={{ margin: '0 auto 8px' }} />
        <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: 0 }}>
          Tap to choose a video file (demo only)
        </p>
      </div>

      <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>
        Title
      </label>
      <input
        style={{ ...inputStyle, marginBottom: 16 }}
        placeholder="Give your video a title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        maxLength={100}
      />

      <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>
        Description
      </label>
      <textarea
        style={{ ...inputStyle, marginBottom: 16, minHeight: 80, resize: 'vertical' }}
        placeholder="What's this video about?"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        maxLength={300}
      />

      <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>
        Hashtags
      </label>
      <input
        style={{ ...inputStyle, marginBottom: 16 }}
        placeholder="#xstream #demo"
        value={hashtags}
        onChange={(e) => setHashtags(e.target.value)}
      />

      <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 8 }}>
        Thumbnail
      </label>
      <div style={{ display: 'flex', gap: 8, marginBottom: 24, flexWrap: 'wrap' }}>
        {thumbnailOptions.map((g) => (
          <button
            key={g}
            onClick={() => setThumbnail(g)}
            aria-label="Select thumbnail"
            style={{
              width: 48,
              height: 84,
              borderRadius: 6,
              background: g,
              border: thumbnail === g ? '2px solid var(--accent)' : '1px solid var(--border)',
            }}
          />
        ))}
      </div>

      <button
        disabled={!canPublish}
        onClick={() => setPublished(true)}
        style={{
          width: '100%',
          padding: '13px 0',
          borderRadius: 8,
          border: 'none',
          fontSize: 15,
          fontWeight: 700,
          color: '#171000',
          background: canPublish ? 'var(--accent)' : 'var(--surface-elevated)',
          opacity: canPublish ? 1 : 0.6,
        }}
      >
        Publish
      </button>
    </div>
  )
}
