import { Users } from 'lucide-react'
import VideoFeed from '../components/feed/VideoFeed'
import { videos, followedCreatorIds } from '../data/mockData'

export default function Following() {
  const followedVideos = videos.filter((v) => followedCreatorIds.includes(v.creator.id))

  return (
    <VideoFeed
      videos={followedVideos}
      emptyState={
        <div style={{ textAlign: 'center', padding: '0 32px', color: 'var(--text-muted)' }}>
          <Users size={30} style={{ margin: '0 auto 12px' }} />
          <p style={{ fontSize: 14 }}>
            Videos from creators you follow will show up here.
          </p>
        </div>
      }
    />
  )
}
