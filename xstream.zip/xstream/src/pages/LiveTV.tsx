export default function LiveTV() {
  return (
    <div style={{ padding: '40px 20px', textAlign: 'center' }}>
      <h1 style={{ fontSize: 20, marginBottom: 8 }}>Live TV</h1>
      <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>
        This section is scaffolded and ready to build out next.
      </p>
    </div>
  )
}
