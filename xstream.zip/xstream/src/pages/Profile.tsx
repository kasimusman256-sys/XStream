import { useState } from 'react'
import { Settings } from 'lucide-react'
import { demoUser, videos } from '../data/mockData'
import { formatCount } from '../utils/format'

type Tab = 'videos' | 'favorites'

export default function Profile() {
  const [tab, setTab] = useState<Tab>('videos')

  const myVideos = videos.filter((v) => v.creator.username === demoUser.handle)
  const favoriteVideos = videos.filter((v) => v.favoritedByUser)
  const shown = tab === 'videos' ? myVideos : favoriteVideos

  return (
    <div style={{ padding: '20px 16px 40px' }}>
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 4 }}>
        <Settings size={20} color="var(--text-muted)" />
      </div>

      <div style={{ textAlign: 'center', marginBottom: 18 }}>
        <div
          style={{
            width: 78,
            height: 78,
            borderRadius: '50%',
            background: demoUser.avatarGradient,
            margin: '0 auto 10px',
            border: '2px solid var(--border)',
          }}
        />
        <h1 style={{ fontSize: 18, marginBottom: 2 }}>{demoUser.name}</h1>
        <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 10 }}>{demoUser.handle}</p>
        <p style={{ fontSize: 13, color: 'var(--text)', maxWidth: 280, margin: '0 auto 16px' }}>
          {demoUser.bio}
        </p>

        <div style={{ display: 'flex', justifyContent: 'center', gap: 28, marginBottom: 18 }}>
          <Stat label="Following" value={demoUser.following} />
          <Stat label="Followers" value={demoUser.followers} />
          <Stat label="Likes" value={demoUser.likes} />
        </div>

        <button
          style={{
            width: '100%',
            maxWidth: 260,
            padding: '10px 0',
            borderRadius: 8,
            border: 'none',
            background: 'var(--accent)',
            color: '#171000',
            fontWeight: 700,
            fontSize: 14,
          }}
        >
          Edit Profile
        </button>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', borderBottom: '1px solid var(--border)', marginBottom: 12 }}>
        {(['videos', 'favorites'] as Tab[]).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            style={{
              flex: 1,
              padding: '10px 0',
              background: 'transparent',
              border: 'none',
              fontSize: 13,
              fontWeight: 700,
              color: tab === t ? 'var(--accent)' : 'var(--text-muted)',
              borderBottom: tab === t ? '2px solid var(--accent)' : '2px solid transparent',
              textTransform: 'capitalize',
            }}
          >
            {t}
          </button>
        ))}
      </div>

      {shown.length === 0 ? (
        <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: 13, padding: '24px 0' }}>
          {tab === 'videos' ? "You haven't posted any videos yet." : "You haven't favorited any videos yet."}
        </p>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6 }}>
          {shown.map((v) => (
            <div
              key={v.id}
              style={{
                aspectRatio: '9 / 16',
                borderRadius: 8,
                background: v.gradient,
                border: '1px solid var(--border)',
                position: 'relative',
                overflow: 'hidden',
              }}
            >
              <span
                style={{
                  position: 'absolute',
                  left: 6,
                  bottom: 6,
                  right: 6,
                  fontSize: 11,
                  color: '#fff',
                  fontWeight: 600,
                  textShadow: '0 1px 3px rgba(0,0,0,0.7)',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                }}
              >
                ♥ {formatCount(v.stats.likes)}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div style={{ textAlign: 'center' }}>
      <p style={{ fontSize: 16, fontWeight: 700, margin: 0 }}>{formatCount(value)}</p>
      <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: 0 }}>{label}</p>
    </div>
  )
}
